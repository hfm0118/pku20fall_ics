/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_394(unsigned x)
{
    return x + 2428995904U;
}

void setval_462(unsigned *p)
{
    *p = 3433808472U;
}

void setval_169(unsigned *p)
{
    *p = 2425393752U;
}

void setval_159(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_355(unsigned x)
{
    return x + 3277361389U;
}

unsigned getval_314()
{
    return 3277340900U;
}

void setval_354(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_346(unsigned x)
{
    return x + 2445773128U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_253()
{
    return 3223377609U;
}

unsigned addval_145(unsigned x)
{
    return x + 3284238826U;
}

unsigned addval_410(unsigned x)
{
    return x + 3398270164U;
}

unsigned addval_230(unsigned x)
{
    return x + 3223896457U;
}

unsigned addval_199(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_276(unsigned x)
{
    return x + 3767093798U;
}

void setval_305(unsigned *p)
{
    *p = 2425405897U;
}

void setval_282(unsigned *p)
{
    *p = 3531917833U;
}

unsigned getval_388()
{
    return 2430634328U;
}

unsigned getval_322()
{
    return 3381974665U;
}

void setval_193(unsigned *p)
{
    *p = 3524840073U;
}

unsigned addval_324(unsigned x)
{
    return x + 3286272330U;
}

unsigned getval_340()
{
    return 3224947337U;
}

unsigned addval_329(unsigned x)
{
    return x + 3677407881U;
}

void setval_333(unsigned *p)
{
    *p = 2425673353U;
}

unsigned addval_150(unsigned x)
{
    return x + 3526412937U;
}

unsigned addval_496(unsigned x)
{
    return x + 2430634248U;
}

unsigned getval_371()
{
    return 3531134601U;
}

unsigned addval_249(unsigned x)
{
    return x + 3224950473U;
}

unsigned addval_158(unsigned x)
{
    return x + 3525367433U;
}

unsigned addval_219(unsigned x)
{
    return x + 3224945037U;
}

unsigned addval_459(unsigned x)
{
    return x + 3400078904U;
}

unsigned addval_334(unsigned x)
{
    return x + 3523789193U;
}

unsigned getval_298()
{
    return 2430634313U;
}

unsigned addval_472(unsigned x)
{
    return x + 3224947337U;
}

unsigned addval_327(unsigned x)
{
    return x + 2430642504U;
}

unsigned addval_251(unsigned x)
{
    return x + 3523794569U;
}

void setval_358(unsigned *p)
{
    *p = 3767093383U;
}

void setval_208(unsigned *p)
{
    *p = 3526934925U;
}

unsigned getval_273()
{
    return 3378561417U;
}

unsigned getval_269()
{
    return 3281043849U;
}

void setval_277(unsigned *p)
{
    *p = 3675838089U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
